About this project
==================

This project is trying to config the nagios automatic.

There are two kinds of styles.

One is command line, and another is GUI.

The program trying to filter data from redmine/mosaic and trying to
config the nagios automatic.

And deploy the configuration to dev/inc automatic.

How to use
==========

::

    ./nagios.py --help
    ./nagios.py -h

TODO
====

1. xnagios.service.py need finish in 4.0.0.0.
2. enhancement other functions.

